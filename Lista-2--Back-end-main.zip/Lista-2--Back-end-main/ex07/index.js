const express = require('express')
const app = express()
const port = 3000

app.use(express.json())

app.post('/exercicio7', (req, res) => {
    let listaItens = []

    req.body.forEach(item => {
        listaItens.push(item)
    });

    let maiorPrecoLido = 0
    listaItens.forEach(item => {
        if (item.preco > maiorPrecoLido){
            maiorPrecoLido = item.preco
        }
    })

    let soma = 0
    console.log("soma ", soma)
    listaItens.forEach(item => {
        console.log("item preco ", item.preco)
        soma = soma + item.preco
        console.log("soma ", soma)
    })

    let media = soma / listaItens.length

    res.json({
        maiorPrecoLido: maiorPrecoLido,
        media: media.toFixed(2)
    })
})


app.listen(port, () => {
    console.log("Aplicação iniciada em http://localhost:3000")
})
