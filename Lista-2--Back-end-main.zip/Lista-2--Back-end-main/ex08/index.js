const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

const tabelaCargos = {
    101: 0.05,
    102: 0.075,
    103: 0.10
};

app.post('/exercicio8', (req, res) => {
    const { remuneracao, codigoCargo } = req.body;

    let aumentoPercentual = tabelaCargos[codigoCargo] || 0.15;
    let novaRemuneracao = remuneracao * (1 + aumentoPercentual);
    let diferenca = novaRemuneracao - remuneracao;

    res.json({
        remuneracaoAntiga: remuneracao,
        novaRemuneracao: novaRemuneracao.toFixed(2),
        diferenca: diferenca.toFixed(2)
    });
});

app.listen(port, () => {
    console.log("Servidor iniciado em http://localhost:3000");
});
