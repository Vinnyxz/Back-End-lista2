const express = require('express')
const app = express()
const port = 3000

app.use(express.json())

app.post('/nivel-estoque', (req, res) => {
    const quantidadeMinima = req.body.quantidadeMinima
    const quantidadeMaxima = req.body.quantidadeMaxima

    const nivelEstoque = (quantidadeMinima + quantidadeMaxima) / 2

    res.json({
        nivelEstoque: nivelEstoque
    })
})

app.listen(port, () => {
    console.log("Servidor iniciado em http://localhost:3000")
})

