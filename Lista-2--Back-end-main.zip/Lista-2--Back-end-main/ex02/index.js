const express = require('express')
const app = express()
const port = 3000

app.use(express.json())

app.post('/aumento-remuneracao', (req, res) => {
    const remuneracao = req.body.remuneracao

    if (remuneracao < 1000) {
        const remuneracaoReajustada = remuneracao * 1.3 
        res.json({
            remuneracaoReajustada: remuneracaoReajustada.toFixed(2)
        })
    } else {
        res.json({
            mensagem: "Funcionário não tem direito ao aumento."
        })
    }
})

app.listen(port, () => {
    console.log("Aplicação iniciada em http://localhost:3000")
})
