const express = require('express')
const app = express()
const port = 3000

app.use(express.json())

app.post('/calcular-remuneracao', (req, res) => {
    const nomeVendedor = req.body.nome
    const remuneracaoFixa = req.body.remuneracaoFixa
    const totalVendas = req.body.totalVendas
    const percentualComissao = req.body.percentualComissao

    const remuneracaoTotal = remuneracaoFixa + (totalVendas * (percentualComissao / 100))

    res.json({
        nomeVendedor: nomeVendedor,
        remuneracaoTotal: remuneracaoTotal.toFixed(2)
    })
})

app.listen(port, () => {
    console.log("Servidor iniciado em http://localhost:3000")
})
