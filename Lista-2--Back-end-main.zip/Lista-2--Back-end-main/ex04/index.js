const express = require('express')
const app = express()
const port = 3000

app.use(express.json())

app.post('/calcular-velocidade-media', (req, res) => {
    const nomeCorredor = req.body.nome
    const distanciaPercorrida = req.body.distancia
    const tempoPercorrido = req.body.tempo

    const velocidadeMedia = distanciaPercorrida / tempoPercorrido

    res.json({
        mensagem: `A velocidade média do ${nomeCorredor} foi ${velocidadeMedia.toFixed(2)} km/h.`
    })
})

app.listen(port, () => {
    console.log("Servidor iniciado em http://localhost:3000")
})
