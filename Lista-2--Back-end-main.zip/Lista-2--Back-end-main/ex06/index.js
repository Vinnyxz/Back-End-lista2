const express = require('express')
const app = express()
const port = 3000

app.use(express.json())

app.post('/calcularPesoDesejado', (req, res) => {
    const { altura, genero } = req.body;
    let pesoDesejado;

    if (genero.toLowerCase() === 'masculino') {
        pesoDesejado = (72.7 * altura) - 58;
    } else if (genero.toLowerCase() === 'feminino') {
        pesoDesejado = (62.1 * altura) - 44.7;
    } else {
        return res.status(400).json({ error: "Gênero inválido. Por favor, insira 'masculino' ou 'feminino'." });
    }

    res.json({
        pesoDesejado: pesoDesejado.toFixed(2)
    });
});

app.listen(port, () => {
    console.log("Servidor iniciado em http://localhost:3000")
});
