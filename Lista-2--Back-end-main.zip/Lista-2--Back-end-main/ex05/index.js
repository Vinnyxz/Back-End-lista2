const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

app.post('/reajustar-remuneracao', (req, res) => {
    const remuneracao = req.body.remuneracao;

    let remuneracaoReajustada;

    if (remuneracao <= 2000) {
        remuneracaoReajustada = remuneracao * 1.5; 
    } else {
        remuneracaoReajustada = remuneracao * 1.3; 
    }

    res.json({
        remuneracaoReajustada: remuneracaoReajustada.toFixed(2)
    });
});

app.listen(port, () => {
    console.log(`Servidor iniciado em http://localhost:3000`);
});
