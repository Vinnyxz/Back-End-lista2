const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

app.post('/calcularRemuneracao', (req, res) => {
    const { remuneracaoMinima, horasTrabalhadas, dependentes, horasExtras } = req.body;

    const valorHora = remuneracaoMinima / 5;

    let remuneracaoMes = horasTrabalhadas * valorHora;
    remuneracaoMes += dependentes * 32;

    const valorHoraExtra = valorHora * 1.5;
    const valorHorasExtras = horasExtras * valorHoraExtra;

    let remuneracaoBruta = remuneracaoMes + valorHorasExtras;

    let irrf;
    if (remuneracaoBruta <= 2000) {
        irrf = 0;
    } else if (remuneracaoBruta > 2000 && remuneracaoBruta <= 5000) {
        irrf = remuneracaoBruta * 0.1;
    } else {
        irrf = remuneracaoBruta * 0.2;
    }

    const remuneracaoLiquida = remuneracaoBruta - irrf;

    let gratificacao;
    if (remuneracaoLiquida <= 3500) {
        gratificacao = 1000;
    } else {
        gratificacao = 500;
    }

    const remuneracaoReceber = remuneracaoLiquida + gratificacao;

    res.json({
        remuneracaoLiquida: remuneracaoLiquida.toFixed(2),
        gratificacao: gratificacao.toFixed(2),
        remuneracaoReceber: remuneracaoReceber.toFixed(2)
    });
});

app.listen(port, () => {
    console.log("Servidor iniciado em http://localhost:3000");
});
